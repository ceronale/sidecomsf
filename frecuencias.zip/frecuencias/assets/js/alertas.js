function insert()
{
 Swal.fire({
     position: 'top-end',
     icon: 'success',
     title: 'El Tipo de Producto se ha registrado con exito!',
     showConfirmButton: false,
     timer: 3000
 })
}

function update()
{
  Swal.fire({
      position: 'top-end',
      icon: 'success',
      title: 'El Tipo de Producto se ha modificado con exito!',
      showConfirmButton: false,
      timer: 3000
  })

}



